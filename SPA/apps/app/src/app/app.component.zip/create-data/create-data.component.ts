import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'spa-create-data',
  templateUrl: './create-data.component.html',
  styleUrls: ['./create-data.component.scss']
})
export class CreateDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
